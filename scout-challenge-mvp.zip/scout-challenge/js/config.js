// ============================================================
// SCOUT CHALLENGE — SUPABASE CONFIG
// ============================================================
// 1. Go to https://supabase.com and create a free project
// 2. In your project: Settings → API
// 3. Copy your Project URL and anon/public key below
// ============================================================

const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';

// Current GameWeek number — update this each week
const CURRENT_GW = 1;

// Deadline (Friday 2pm Paris time) — update each week
const GW_DEADLINE = new Date('2025-08-08T14:00:00+02:00');

// Flair threshold — player selected by less than X% of users gets +3 pts
const FLAIR_THRESHOLD = 10;

// Position groups mapping
const POS_GROUPS = {
  'ATT': ['BU', 'AD', 'AG'],
  'MID': ['MC', 'MDC', 'MOC', 'MG'],
  'DEF': ['DC', 'DD', 'DG'],
  'GK':  ['GK', 'GB']
};

// Scout levels
const SCOUT_LEVELS = [
  { name: 'Rookie Scout',  xpMin: 0,    xpMax: 500  },
  { name: 'Pro Scout',     xpMin: 500,  xpMax: 1500 },
  { name: 'Elite Scout',   xpMin: 1500, xpMax: 3000 },
  { name: 'Master Scout',  xpMin: 3000, xpMax: 99999 }
];
