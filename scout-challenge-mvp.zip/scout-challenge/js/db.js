// ============================================================
// SCOUT CHALLENGE — DATABASE LAYER (Supabase)
// ============================================================

let supabase = null;

async function initSupabase() {
  if (SUPABASE_URL === 'YOUR_SUPABASE_URL') {
    console.warn('Supabase not configured — running in demo mode');
    return false;
  }
  const { createClient } = await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm');
  supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  return true;
}

// ---- USERS ----

async function createUser(pseudo, email) {
  if (!supabase) return mockUser(pseudo, email);
  const { data, error } = await supabase
    .from('users')
    .insert([{ pseudo, email, created_at: new Date().toISOString() }])
    .select()
    .single();
  if (error) throw error;
  return data;
}

async function getUserByEmail(email) {
  if (!supabase) return mockUser('Scout', email);
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('email', email)
    .single();
  if (error) return null;
  return data;
}

// ---- PLAYERS ----

async function getPlayers() {
  if (!supabase) return DEMO_PLAYERS;
  const { data, error } = await supabase
    .from('players')
    .select('*')
    .eq('actif', 'OUI')
    .order('nom');
  if (error) { console.error(error); return DEMO_PLAYERS; }
  return data;
}

// ---- SELECTIONS ----

async function saveSelection(userId, gw, selection) {
  if (!supabase) return { success: true };
  const { data, error } = await supabase
    .from('selections')
    .upsert([{
      user_id: userId,
      gameweek: gw,
      captain_id: selection.captain?.id || null,
      starter1_id: selection.starters[0]?.id || null,
      starter2_id: selection.starters[1]?.id || null,
      starter3_id: selection.starters[2]?.id || null,
      sub_id: selection.sub?.id || null,
      locked: false,
      updated_at: new Date().toISOString()
    }], { onConflict: 'user_id,gameweek' });
  if (error) throw error;
  return { success: true };
}

async function getMySelection(userId, gw) {
  if (!supabase) return null;
  const { data } = await supabase
    .from('selections')
    .select('*')
    .eq('user_id', userId)
    .eq('gameweek', gw)
    .single();
  return data;
}

// ---- SCORES & RANKINGS ----

async function getRankings(gw = null) {
  if (!supabase) return DEMO_RANKINGS;
  let query = supabase
    .from('scores')
    .select('user_id, users(pseudo), total_pts, gw_pts, gameweek')
    .order('total_pts', { ascending: false })
    .limit(50);
  if (gw) query = query.eq('gameweek', gw);
  const { data, error } = await query;
  if (error) return DEMO_RANKINGS;
  return data;
}

async function getPlayerSelectionRate(playerId, gw) {
  if (!supabase) return Math.random() * 20;
  const { count: total } = await supabase
    .from('selections')
    .select('*', { count: 'exact', head: true })
    .eq('gameweek', gw);
  if (!total) return 0;
  const { count: picked } = await supabase
    .from('selections')
    .select('*', { count: 'exact', head: true })
    .eq('gameweek', gw)
    .or(`captain_id.eq.${playerId},starter1_id.eq.${playerId},starter2_id.eq.${playerId},starter3_id.eq.${playerId},sub_id.eq.${playerId}`);
  return ((picked / total) * 100).toFixed(1);
}

// ---- MOCK DATA (demo mode when Supabase not configured) ----

function mockUser(pseudo, email) {
  return { id: 'demo-user', pseudo, email, created_at: new Date().toISOString() };
}

const DEMO_PLAYERS = [
  { id: 'SC0001', nom: 'Désiré Doué',      club: 'PSG',             championnat: 'Ligue 1',      poste: 'AD',  image_url: '' },
  { id: 'SC0002', nom: 'Ethan Nwaneri',    club: 'Arsenal',         championnat: 'Premier League', poste: 'MOC', image_url: '' },
  { id: 'SC0003', nom: 'Kenan Yildiz',     club: 'Juventus',        championnat: 'Serie A',      poste: 'MOC', image_url: '' },
  { id: 'SC0004', nom: 'Antoine Semenyo',  club: 'Bournemouth',     championnat: 'Premier League', poste: 'AD', image_url: '' },
  { id: 'SC0005', nom: 'Warren Zaïre-Emery', club: 'PSG',          championnat: 'Ligue 1',      poste: 'MC',  image_url: '' },
  { id: 'SC0006', nom: 'Lamine Yamal',     club: 'FC Barcelona',    championnat: 'Liga',         poste: 'AD',  image_url: '' },
  { id: 'SC0007', nom: 'Pedri',            club: 'FC Barcelona',    championnat: 'Liga',         poste: 'MC',  image_url: '' },
  { id: 'SC0008', nom: 'Florian Wirtz',    club: 'Bayer Leverkusen', championnat: 'Bundesliga',  poste: 'MOC', image_url: '' },
  { id: 'SC0009', nom: 'Xavi Simons',      club: 'PSG',             championnat: 'Ligue 1',      poste: 'MOC', image_url: '' },
  { id: 'SC0010', nom: 'Mathys Tel',       club: 'Bayern Munich',   championnat: 'Bundesliga',   poste: 'AD',  image_url: '' },
  { id: 'SC0011', nom: 'Karim Adeyemi',    club: 'Borussia Dortmund', championnat: 'Bundesliga', poste: 'AG',  image_url: '' },
  { id: 'SC0012', nom: 'Savio',            club: 'Manchester City', championnat: 'Premier League', poste: 'AD', image_url: '' },
  { id: 'SC0013', nom: 'Joao Neves',       club: 'PSG',             championnat: 'Ligue 1',      poste: 'MDC', image_url: '' },
  { id: 'SC0014', nom: 'Leny Yoro',        club: 'Manchester United', championnat: 'Premier League', poste: 'DC', image_url: '' },
  { id: 'SC0015', nom: 'Jorrel Hato',      club: 'Ajax',            championnat: 'Eredivisie',   poste: 'DC',  image_url: '' },
];

const DEMO_RANKINGS = [
  { pseudo: 'ScoutKing',    total_pts: 1284, flag: '🇬🇧' },
  { pseudo: 'MadridFlair',  total_pts: 1201, flag: '🇪🇸' },
  { pseudo: 'LionelScout',  total_pts: 1189, flag: '🇦🇷' },
  { pseudo: 'TalentHunter', total_pts: 1142, flag: '🇩🇪' },
  { pseudo: 'PepiteWatch',  total_pts: 1098, flag: '🇧🇷' },
  { pseudo: 'NextGenFind',  total_pts: 1054, flag: '🇳🇱' },
];
