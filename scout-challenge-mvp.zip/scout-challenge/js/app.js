// ============================================================
// SCOUT CHALLENGE — MAIN APP LOGIC
// ============================================================

let currentUser = null;
let allPlayers = [];
let currentSelection = { captain: null, starters: [], sub: null };
let filteredLeague = 'all';
let filteredPos = 'all';
let currentPickSlot = null;
let rankTab = 'overall';

// ---- INIT ----

window.addEventListener('DOMContentLoaded', async () => {
  await initSupabase();
  const saved = localStorage.getItem('sc_user');
  if (saved) {
    currentUser = JSON.parse(saved);
    showApp();
  }
  updateDeadline();
});

// ---- AUTH ----

function handleAuth() {
  const pseudo = document.getElementById('input-pseudo').value.trim();
  const email = document.getElementById('input-email').value.trim();
  if (!pseudo || pseudo.length < 3) { showToast('Scout name must be at least 3 characters'); return; }
  if (!isValidEmail(email)) { showToast('Please enter a valid email'); return; }
  currentUser = mockUser(pseudo, email);
  localStorage.setItem('sc_user', JSON.stringify(currentUser));
  showApp();
}

function handleLogin() {
  document.getElementById('auth-form').classList.add('hidden');
  document.getElementById('login-form').classList.remove('hidden');
}

function handleRegister() {
  document.getElementById('login-form').classList.add('hidden');
  document.getElementById('auth-form').classList.remove('hidden');
}

function handleLoginSubmit() {
  const email = document.getElementById('input-login-email').value.trim();
  if (!isValidEmail(email)) { showToast('Please enter a valid email'); return; }
  const saved = localStorage.getItem('sc_user');
  if (saved) {
    const user = JSON.parse(saved);
    if (user.email === email) {
      currentUser = user;
      showApp();
      return;
    }
  }
  showToast('No account found with this email');
}

function handleLogout() {
  localStorage.removeItem('sc_user');
  currentUser = null;
  document.getElementById('screen-app').classList.remove('active');
  document.getElementById('screen-auth').classList.add('active');
  document.getElementById('auth-form').classList.remove('hidden');
  document.getElementById('login-form').classList.add('hidden');
}

function showApp() {
  document.getElementById('screen-auth').classList.remove('active');
  document.getElementById('screen-app').classList.add('active');
  loadPlayers();
  renderProfile();
  renderRankings();
  renderHome();
}

// ---- NAVIGATION ----

function goToPage(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  document.querySelector(`[data-page="${page}"]`).classList.add('active');
  if (page === 'ranking') renderRankings();
  if (page === 'profile') renderProfile();
}

function goToPicks(slot) {
  if (isDeadlinePassed()) { showToast('Deadline passed — picks are locked'); return; }
  currentPickSlot = slot;
  goToPage('picks');
  renderPlayers();
}

function goBack() {
  goToPage('home');
}

// ---- PLAYERS ----

async function loadPlayers() {
  allPlayers = await getPlayers();
  renderPlayers();
}

function renderPlayers() {
  const list = document.getElementById('players-list');
  if (!list) return;
  const search = (document.getElementById('search-input')?.value || '').toLowerCase();

  const filtered = allPlayers.filter(p => {
    const matchLeague = filteredLeague === 'all' || p.championnat === filteredLeague;
    const matchPos = filteredPos === 'all' || (POS_GROUPS[filteredPos] || []).includes(p.poste);
    const matchSearch = !search || p.nom.toLowerCase().includes(search) || p.club.toLowerCase().includes(search);
    return matchLeague && matchPos && matchSearch;
  });

  list.innerHTML = filtered.map(p => {
    const selectionRate = Math.floor(Math.random() * 30);
    const isFlair = selectionRate < FLAIR_THRESHOLD;
    const isSelected = isPlayerSelected(p.id);
    const initials = getInitials(p.nom);

    return `
      <div class="player-row" onclick="pickPlayer('${p.id}')">
        <div class="player-row-avatar">
          ${p.image_url ? `<img src="${p.image_url}" alt="${p.nom}" onerror="this.style.display='none'"/>` : ''}
          ${!p.image_url ? initials : ''}
        </div>
        <div class="player-row-info">
          <div class="player-row-name">${p.nom}</div>
          <div class="player-row-club">${p.club} · ${p.championnat}</div>
        </div>
        <div class="player-row-actions">
          ${isFlair ? `<span class="flair-badge">FLAIR</span>` : '<span style="height:20px"></span>'}
          ${isSelected
            ? `<span class="btn-added">Added</span>`
            : `<button class="btn-add" onclick="pickPlayer('${p.id}'); event.stopPropagation()">+ Add</button>`
          }
        </div>
      </div>`;
  }).join('');

  if (filtered.length === 0) {
    list.innerHTML = `<div style="text-align:center;color:var(--text3);padding:40px 20px;font-size:13px">No players found</div>`;
  }
}

function pickPlayer(playerId) {
  const player = allPlayers.find(p => p.id === playerId);
  if (!player) return;

  if (currentPickSlot === 'captain') {
    if (currentSelection.captain?.id === playerId) {
      showToast('Already your captain');
      return;
    }
    currentSelection.captain = player;
    showToast(`${player.nom} set as captain ✓`);
  } else if (currentPickSlot === 'sub') {
    if (isPlayerSelected(playerId)) { showToast('Already in your squad'); return; }
    currentSelection.sub = player;
    showToast(`${player.nom} added as sub ✓`);
  } else {
    if (isPlayerSelected(playerId)) { showToast('Already in your squad'); return; }
    if (currentSelection.starters.length >= 3) { showToast('3 starters already selected'); return; }
    currentSelection.starters.push(player);
    showToast(`${player.nom} added ✓`);
  }

  renderHome();
  renderPlayers();

  const totalSelected = (currentSelection.captain ? 1 : 0) + currentSelection.starters.length + (currentSelection.sub ? 1 : 0);
  if (totalSelected >= 5) {
    setTimeout(() => goToPage('home'), 400);
  }
}

function isPlayerSelected(playerId) {
  return (
    currentSelection.captain?.id === playerId ||
    currentSelection.starters.some(p => p.id === playerId) ||
    currentSelection.sub?.id === playerId
  );
}

// ---- HOME RENDER ----

function renderHome() {
  renderCaptainSlot();
  renderStarterSlots();
  renderSubSlot();
  renderFlairSection();
  renderConfirmButton();
}

function renderCaptainSlot() {
  const slot = document.getElementById('captain-slot');
  const empty = document.getElementById('captain-empty');
  const card = document.getElementById('captain-card');
  const p = currentSelection.captain;

  if (p) {
    empty.classList.add('hidden');
    card.classList.remove('hidden');
    card.innerHTML = `
      <div class="player-card-captain">
        <div style="display:flex;align-items:center;gap:12px">
          <div class="player-avatar">
            ${p.image_url ? `<img src="${p.image_url}" alt="${p.nom}"/>` : getInitials(p.nom)}
          </div>
          <div>
            <div class="player-name">${p.nom}</div>
            <div class="player-meta">${p.club} · ${p.championnat}</div>
          </div>
        </div>
        <div style="text-align:right">
          <div style="font-size:10px;color:rgba(255,255,255,0.5);letter-spacing:1px">CAPTAIN</div>
          <div style="font-size:22px;font-weight:700;color:#fff;font-family:var(--font-display)">×1.5</div>
        </div>
      </div>`;
  } else {
    empty.classList.remove('hidden');
    card.classList.add('hidden');
  }
}

function renderStarterSlots() {
  const grid = document.getElementById('starters-grid');
  const slots = Array(3).fill(null).map((_, i) => currentSelection.starters[i] || null);

  grid.innerHTML = slots.map((p, i) => {
    if (p) {
      return `
        <div class="starter-slot" onclick="removeStarter(${i})" style="border-color:var(--border2)">
          <div class="player-card-small">
            <div class="player-avatar" style="border:0.5px solid var(--border2)">
              ${p.image_url ? `<img src="${p.image_url}" alt="${p.nom}"/>` : getInitials(p.nom)}
            </div>
            <div class="player-name-sm">${p.nom.split(' ').slice(-1)[0]}</div>
            <div class="player-meta-sm">${p.club}</div>
          </div>
        </div>`;
    }
    return `
      <div class="starter-slot" onclick="goToPicks('starter')">
        <div class="slot-empty-small">
          <div class="slot-plus" style="border-color:var(--border2);color:var(--text3)">+</div>
        </div>
      </div>`;
  }).join('');
}

function renderSubSlot() {
  const slot = document.getElementById('sub-slot');
  const p = currentSelection.sub;

  if (p) {
    slot.innerHTML = `
      <div style="padding:12px 14px;display:flex;align-items:center;gap:12px" onclick="removeSub()">
        <div class="player-avatar" style="width:36px;height:36px;border:0.5px solid var(--border2)">
          ${p.image_url ? `<img src="${p.image_url}" alt="${p.nom}"/>` : getInitials(p.nom)}
        </div>
        <div>
          <div style="font-size:13px;font-weight:600;color:var(--text)">${p.nom}</div>
          <div style="font-size:10px;color:var(--text3)">${p.club} · SUB</div>
        </div>
        <div style="margin-left:auto;font-size:10px;color:var(--text3)">tap to remove</div>
      </div>`;
  } else {
    slot.innerHTML = `
      <div class="slot-empty-sub" onclick="goToPicks('sub')">
        <div class="slot-plus" style="border-color:var(--border2);color:var(--text3)">+</div>
        <span class="slot-text">Add a sub — activates if a starter doesn't play</span>
      </div>`;
  }
}

function renderFlairSection() {
  const section = document.getElementById('flair-section');
  const list = document.getElementById('flair-list');
  const allPicks = [currentSelection.captain, ...currentSelection.starters, currentSelection.sub].filter(Boolean);
  const flairPicks = allPicks.filter(() => Math.random() < 0.4);

  if (flairPicks.length > 0) {
    section.classList.remove('hidden');
    list.innerHTML = flairPicks.map(p => `
      <div class="flair-item">
        <div class="flair-player">
          <div class="player-avatar" style="width:30px;height:30px;font-size:12px">
            ${p.image_url ? `<img src="${p.image_url}" alt="${p.nom}"/>` : getInitials(p.nom)}
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--text)">${p.nom}</div>
            <div style="font-size:10px;color:var(--text3)">${p.club}</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <span class="flair-pct">${(Math.random() * 9).toFixed(1)}%</span>
          <span class="flair-badge">+3 FLAIR</span>
        </div>
      </div>`).join('');
  } else {
    section.classList.add('hidden');
  }
}

function renderConfirmButton() {
  const btn = document.getElementById('btn-confirm');
  const hasMinPicks = currentSelection.captain && currentSelection.starters.length === 3;
  if (hasMinPicks) {
    btn.classList.remove('hidden');
  } else {
    btn.classList.add('hidden');
  }
  btn.onclick = confirmSelection;
}

function removeStarter(index) {
  currentSelection.starters.splice(index, 1);
  renderHome();
  renderPlayers();
}

function removeSub() {
  currentSelection.sub = null;
  renderHome();
  renderPlayers();
}

async function confirmSelection() {
  if (isDeadlinePassed()) { showToast('Deadline passed — picks are locked'); return; }
  try {
    await saveSelection(currentUser.id, CURRENT_GW, currentSelection);
    showToast('Selection locked in! ✓');
    document.getElementById('btn-confirm').textContent = 'Selection saved ✓';
    document.getElementById('btn-confirm').style.background = 'var(--green-dark)';
    document.getElementById('btn-confirm').style.color = 'var(--green)';
    document.getElementById('btn-confirm').style.border = '0.5px solid var(--green-border)';
  } catch (e) {
    showToast('Error saving — please try again');
  }
}

// ---- FILTERS ----

function setLeagueFilter(btn, league) {
  filteredLeague = league;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderPlayers();
}

function setPosFilter(btn, pos) {
  filteredPos = pos;
  document.querySelectorAll('.pos-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderPlayers();
}

function filterPlayers() { renderPlayers(); }

// ---- RANKINGS ----

async function renderRankings() {
  const rankings = await getRankings(rankTab === 'gw' ? CURRENT_GW : null);
  renderPodium(rankings);
  renderRankList(rankings);
}

function setRankTab(btn, tab) {
  rankTab = tab;
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  renderRankings();
}

function renderPodium(rankings) {
  const podium = document.getElementById('podium');
  if (!rankings || rankings.length < 3) { podium.innerHTML = ''; return; }

  const myPseudo = currentUser?.pseudo;
  const topThree = [rankings[1], rankings[0], rankings[2]];
  const classes = ['podium-2', 'podium-1', 'podium-3'];
  const ranks = ['2ND', '1ST', '3RD'];

  podium.innerHTML = topThree.map((r, i) => {
    const pseudo = r.pseudo || r.users?.pseudo || 'Scout';
    const pts = r.total_pts || r.gw_pts || 0;
    const isMe = pseudo === myPseudo;
    return `
      <div class="podium-item ${classes[i]}">
        <div class="podium-avatar" style="${isMe ? 'border:2px solid var(--red);color:var(--red);background:var(--red-dark)' : ''}">
          ${getInitials(pseudo)}
        </div>
        <div class="podium-name">${pseudo}${isMe ? ' <span style="font-size:9px;color:var(--red)">YOU</span>' : ''}</div>
        <div class="podium-flag">${r.flag || '🌍'}</div>
        <div class="podium-score-box">
          <div class="podium-rank">${ranks[i]}</div>
          <div class="podium-pts">${pts}</div>
        </div>
      </div>`;
  }).join('');
}

function renderRankList(rankings) {
  const list = document.getElementById('rank-list');
  const myPseudo = currentUser?.pseudo;
  const rest = rankings.slice(3);

  list.innerHTML = rest.map((r, i) => {
    const pseudo = r.pseudo || r.users?.pseudo || 'Scout';
    const pts = r.total_pts || r.gw_pts || 0;
    const isMe = pseudo === myPseudo;
    return `
      <div class="rank-row ${isMe ? 'me' : ''}">
        <div class="rank-num">${i + 4}</div>
        <div class="rank-avatar">${getInitials(pseudo)}</div>
        <div class="rank-info">
          <div class="rank-name">${pseudo}${isMe ? '<span class="me-badge">YOU</span>' : ''}</div>
          <div class="rank-meta">${r.flag || '🌍'} · ${getScoutLevel(pts).name}</div>
        </div>
        <div class="rank-pts">${pts}</div>
      </div>`;
  }).join('');

  // If user not in top list, pin them at the bottom
  const myRank = rankings.findIndex(r => (r.pseudo || r.users?.pseudo) === myPseudo);
  if (myRank < 0 && currentUser) {
    const myPts = 0;
    list.innerHTML += `
      <div style="height:1px;background:var(--border2);margin:8px 0"></div>
      <div class="rank-row me">
        <div class="rank-num">—</div>
        <div class="rank-avatar">${getInitials(currentUser.pseudo)}</div>
        <div class="rank-info">
          <div class="rank-name">${currentUser.pseudo}<span class="me-badge">YOU</span></div>
          <div class="rank-meta">🌍 · ${getScoutLevel(myPts).name}</div>
        </div>
        <div class="rank-pts">${myPts}</div>
      </div>`;
  }
}

// ---- PROFILE ----

function renderProfile() {
  if (!currentUser) return;
  const pseudo = currentUser.pseudo || 'Scout';
  const pts = 0;
  const level = getScoutLevel(pts);
  const nextLevel = getNextLevel(pts);

  document.getElementById('profile-avatar').textContent = getInitials(pseudo);
  document.getElementById('profile-name').textContent = pseudo;
  document.getElementById('profile-meta').textContent = `🌍 · ${level.name}`;
  document.getElementById('xp-level').textContent = level.name;
  document.getElementById('stat-pts').textContent = pts;
  document.getElementById('stat-gw').textContent = CURRENT_GW - 1;
  document.getElementById('stat-flair').textContent = 0;

  const xpInLevel = pts - level.xpMin;
  const xpForLevel = level.xpMax - level.xpMin;
  const pct = Math.min(100, Math.round((xpInLevel / xpForLevel) * 100));
  document.getElementById('xp-fill').style.width = pct + '%';
  document.getElementById('xp-pts').textContent = `${pts} / ${level.xpMax} XP`;

  if (nextLevel) {
    document.getElementById('xp-next').textContent = `${level.xpMax - pts} XP to reach ${nextLevel.name}`;
  } else {
    document.getElementById('xp-next').textContent = 'Maximum level reached';
  }

  renderBadges(pts);
  renderGWHistory();
}

function renderBadges(pts) {
  const badges = [
    { icon: '★', name: 'First Pick', desc: 'First selection made', earned: currentSelection.captain !== null },
    { icon: '◆', name: 'Flair Master', desc: '10 flair picks', earned: false },
    { icon: '▲', name: 'Top 10%', desc: 'Global ranking', earned: false },
    { icon: '◉', name: 'Nations Cup', desc: 'Coming soon', earned: false },
  ];

  document.getElementById('badges-grid').innerHTML = badges.map(b => `
    <div class="badge-item ${b.earned ? 'earned' : ''}">
      <div class="badge-icon" style="color:${b.earned ? 'var(--green)' : 'var(--text3)'}">${b.icon}</div>
      <div>
        <div class="badge-name" style="color:${b.earned ? 'var(--text)' : 'var(--text3)'}">${b.name}</div>
        <div class="badge-desc">${b.desc}</div>
      </div>
    </div>`).join('');
}

function renderGWHistory() {
  const history = document.getElementById('gw-history');
  history.innerHTML = `
    <div class="gw-row">
      <div class="gw-row-left">
        <div class="gw-row-week">GameWeek ${CURRENT_GW}</div>
        <div class="gw-row-note" style="color:var(--red)">In progress</div>
      </div>
      <div class="gw-row-pts" style="color:var(--text3)">—</div>
    </div>`;
}

// ---- DEADLINE ----

function updateDeadline() {
  const el = document.getElementById('deadline-text');
  if (!el) return;
  const now = new Date();
  const diff = GW_DEADLINE - now;

  if (diff <= 0) {
    el.textContent = 'LOCKED';
    el.style.color = 'var(--text3)';
    return;
  }

  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);

  if (days > 0) el.textContent = `${days}D ${hours}H`;
  else el.textContent = `${hours}H LEFT`;

  setTimeout(updateDeadline, 60000);
}

function isDeadlinePassed() {
  return new Date() > GW_DEADLINE;
}

// ---- UTILS ----

function getInitials(name) {
  return name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function getScoutLevel(pts) {
  for (let i = SCOUT_LEVELS.length - 1; i >= 0; i--) {
    if (pts >= SCOUT_LEVELS[i].xpMin) return SCOUT_LEVELS[i];
  }
  return SCOUT_LEVELS[0];
}

function getNextLevel(pts) {
  const current = getScoutLevel(pts);
  const idx = SCOUT_LEVELS.indexOf(current);
  return SCOUT_LEVELS[idx + 1] || null;
}

function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2500);
}
